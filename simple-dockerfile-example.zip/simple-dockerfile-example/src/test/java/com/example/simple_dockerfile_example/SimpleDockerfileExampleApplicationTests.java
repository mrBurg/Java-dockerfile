package com.example.simple_dockerfile_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleDockerfileExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
